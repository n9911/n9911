# Signal Relay — a runnable example

This is synthetic demonstration data for locale-check, curated for the explicitly fictional @n9911 developer persona.

## Try it

Requires Node.js 22+. From the project root run:

```text
node examples/profile-mission/check.mjs
```

Paste source.json and target.json into Locale Check. The report identifies station.ready, help and extra.

Start the full local app using Start.cmd on Windows, or `node server.mjs`; open http://127.0.0.1:8835. The original README contains its complete instructions.

## A useful next change

Add a corrected target JSON and verify that the same source produces zero findings.

The example, assertion script and documentation are new local additions. The application, original authors, LICENSE and existing Git history retain their attribution. The source ZIP contains no Git database; publish a separate repository from the original local Git project to retain its history.
